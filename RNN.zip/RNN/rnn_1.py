a=[235,659,485,61531]
import numpy as np
a=np.asarray(a)
b=a.reshape(-1,1,2)
